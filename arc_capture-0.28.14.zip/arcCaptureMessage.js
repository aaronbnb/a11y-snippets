!// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
function(e,n,t,r,o){/* eslint-disable no-undef */var i="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},u="function"==typeof i[r]&&i[r],s=u.cache||{},f="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function a(n,t){if(!s[n]){if(!e[n]){// if we cannot find the module within our internal map or
// cache jump to the current global require ie. the last bundle
// that was added to the page.
var o="function"==typeof i[r]&&i[r];if(!t&&o)return o(n,!0);// If there are other bundles on this page the require from the
// previous one is saved to 'previousRequire'. Repeat this as
// many times as there are bundles until the module is found or
// we exhaust the require chain.
if(u)return u(n,!0);// Try the node require function if it exists.
if(f&&"string"==typeof n)return f(n);var c=Error("Cannot find module '"+n+"'");throw c.code="MODULE_NOT_FOUND",c}l.resolve=function(t){var r=e[n][1][t];return null!=r?r:t},l.cache={};var d=s[n]=new a.Module(n);e[n][0].call(d.exports,l,d,d.exports,this)}return s[n].exports;function l(e){var n=l.resolve(e);return!1===n?{}:a(n)}}a.isParcelRequire=!0,a.Module=function(e){this.id=e,this.bundle=a,this.exports={}},a.modules=e,a.cache=s,a.parent=u,a.register=function(n,t){e[n]=[function(e,n){n.exports=t},{}]},Object.defineProperty(a,"root",{get:function(){return i[r]}}),i[r]=a;for(var c=0;c<n.length;c++)a(n[c]);if(t){// Expose entry point to Node, AMD or browser globals
// Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
var d=a(t);// CommonJS
"object"==typeof exports&&"undefined"!=typeof module?module.exports=d:"function"==typeof define&&define.amd?define(function(){return d}):o&&(this[o]=d)}}({"88dIc":[function(e,n,t){var r,o,i,u,s=e("@parcel/transformer-js/src/esmodule-helpers.js");s.defineInteropFlag(t),s.export(t,"MessageType",()=>i),s.export(t,"MessageCommand",()=>u),s.export(t,"ArcCaptureMessage",()=>f),(r=i||(i={})).fromBackground="fromBackground",r.toBackground="toBackground",(o=u||(u={})).extensionMessage="extensionMessage",o.inspectTarget="inspectTarget",o.isActiveTab="isActiveTab",o.openLocation="openLocation",o.runARCRules="runARC-Rules",o.getFramesList="getFramesList",o.searchTarget="searchTarget";var f=function(e,n,t){this.extension="arc-capture",this.type=e,this.command=n,t&&(this.data=t)}},{"@parcel/transformer-js/src/esmodule-helpers.js":"lKnE2"}],lKnE2:[function(e,n,t){t.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},t.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},t.exportAll=function(e,n){return Object.keys(e).forEach(function(t){"default"===t||"__esModule"===t||n.hasOwnProperty(t)||Object.defineProperty(n,t,{enumerable:!0,get:function(){return e[t]}})}),n},t.export=function(e,n,t){Object.defineProperty(e,n,{enumerable:!0,get:t})}},{}]},["88dIc"],"88dIc","parcelRequire420a");